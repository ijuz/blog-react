import React,{useEffect,useState} from 'react'
import Header from './Header'
import { Link } from 'react-router-dom'
import './post.css'

import axios from 'axios'
function Posts() {
    const [posts,setPosts]=useState([])
    useEffect(()=>{
        axios
        .get('http://127.0.0.1:8000/api/v1/blog/')
        .then((response)=>{
            setPosts(response.data.data)

        })
    },[])
    const PostsData = ()=>{
        return posts.map((list)=>(
          <li key={list.id} className='li'>
            <Link className='link-component' to={`/posts/${list.id}`}>
              <div className='image-container'>
                  <img src={list.featured_image} alt='feature'/>
              </div>
              <div className='details'>
                <div className='date'>
                  <h2>{list.title}</h2>
                </div>
                <div className='about'>
                      <span className='paragraph-tag'><p>{list.short_description}</p></span>
                  </div>
                <div className='auther'>
                    <h3>{list.author}</h3>
                </div>
              </div>
              <div className='content'>
                  <div className='title'>
                    {list.published_date}
                  </div>
              </div>
            </Link>
          </li>
        ))
    }
  return (
    <>
    <Header/>
   <div className='main-container'>
      <ul className='ul'>
          {PostsData()}
      </ul>
   </div>
   </>
  )
}

export default Posts
