import React from 'react'
import { Link } from 'react-router-dom'
import logo from '../Assets/logo.jpg'
import './header.css'


function Header() {
  return (

    <div className='header-container'>
      <div className='left'>
            <div className='logo-box'>
                <img src={logo} alt='logo'/>
            </div>
      </div>
      <div className='right'>
            <div className='login-btn'>
                <Link to='/login'>
                    login
                </Link>
            </div>
            <div className='create'>
                <span>Create Your Blog</span>
            </div>
      </div>
    </div>
  )
}

export default Header
