import React,{useState,useEffect} from 'react'
import {useParams } from 'react-router-dom'
import './blog.css'
import axios from 'axios'

function Blog() {
    const {id}=useParams()
    const [Data,setData]=useState({})
    useEffect(()=>{
        axios
        .get(`http://127.0.0.1:8000/api/v1/blog/view/${id}/`)
        .then((response)=>{
            setData(response.data.data)
        })
    },[id])
  
  return (
    <div className='main-container'>
        <div className='top'>
            <div className='image'>
                <img src={Data.featured_image} alt='spotlight'/>
            </div>
            <div className='detial'>
                <h1>{Data.title}</h1>
                <div className='writter'>
                    <h1>{Data.author}</h1>
                </div>
                <div className='date'>
                    <h1>{Data.published_date}</h1>
                </div>
            </div>
            <div className='content'>
                <div className='desc'>
                    <h3>{Data.short_description}</h3>
                </div>
                <div className='disc'>
                    <p>
                        {Data.description}
                    </p>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Blog
