import React from 'react'
import Posts from './components/screens/Posts'
import Blog from './components/screens/Blog'
import Signup from './components/screens/Signup'
import Register from './components/screens/Register'
import { BrowserRouter as Router, Route, Routes } from "react-router-dom"

function App() {
  return (
    <div>
      <Router>
        <Routes>
          <Route element={<Posts/>} path='/'/>
          <Route element={<Blog/>} path='/posts/:id/'/>
          <Route element={<Signup/>} path='/login' exact/>
          <Route element={<Register/>}path='/register' exact/>

        </Routes>
      </Router>
     
    </div>
  )
}

export default App
